{{- define "admission-controller-lib.preinstallJob" -}}

{{ include "admission-controller-lib.preinstallRBAC" . }}

---

apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "admission-controller-lib.preinstall.fullname" . }}
  annotations:
    "helm.sh/hook": pre-install,pre-upgrade
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
spec:
  template:
    spec:
      serviceAccountName: {{ include "admission-controller-lib.preinstall.fullname" . }}
      restartPolicy: Never
      containers:
        - name: preinstall
          image: {{ include "admission-controller-lib.image" . }}
          imagePullPolicy: IfNotPresent
          args: ["pre-install"]
          env:
            {{- include "admission-controller-lib.env" . | nindent 12 }}
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end -}}
